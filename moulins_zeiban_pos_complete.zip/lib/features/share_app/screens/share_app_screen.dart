import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/theme/app_theme.dart';

class ShareAppScreen extends StatefulWidget {
  const ShareAppScreen({super.key});

  @override
  State<ShareAppScreen> createState() => _ShareAppScreenState();
}

class _ShareAppScreenState extends State<ShareAppScreen> {
  String? savedPin;
  bool _isPinVerified = false;
  String _enteredPin = '';
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadPin();
  }

  Future<void> _loadPin() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      savedPin = prefs.getString('user_pin');
    });
  }

  void _onNumberPressed(String number) {
    if (_enteredPin.length < 4) {
      setState(() {
        _enteredPin += number;
        _errorMessage = '';
      });
      if (_enteredPin.length == 4) {
        _verifyPin();
      }
    }
  }

  void _onBackspace() {
    if (_enteredPin.isNotEmpty) {
      setState(() {
        _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1);
        _errorMessage = '';
      });
    }
  }

  void _verifyPin() {
    if (_enteredPin == savedPin) {
      setState(() {
        _isPinVerified = true;
      });
    } else {
      setState(() {
        _errorMessage = 'كلمة السر غير صحيحة';
        _enteredPin = '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مشاركة التطبيق'),
      ),
      body: _isPinVerified ? _buildShareOptions() : _buildPinVerification(),
    );
  }

  Widget _buildPinVerification() {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(24),
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.lock,
              size: 60,
              color: AppTheme.primaryGreen,
            ),
            const SizedBox(height: 20),
            Text(
              'أدخل كلمة السر',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'مشاركة التطبيق الرئيسي تتطلب التحقق',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppTheme.textSecondary,
              ),
            ),
            const SizedBox(height: 24),
            // PIN Dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(4, (index) {
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 12),
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: index < _enteredPin.length
                        ? AppTheme.primaryGreen
                        : Colors.grey.shade300,
                    border: Border.all(
                      color: AppTheme.primaryGreen,
                      width: 2,
                    ),
                  ),
                );
              }),
            ),
            if (_errorMessage.isNotEmpty) ...[
              const SizedBox(height: 16),
              Text(
                _errorMessage,
                style: const TextStyle(
                  color: AppTheme.errorColor,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
            const SizedBox(height: 32),
            // Number Pad
            GridView.count(
              shrinkWrap: true,
              crossAxisCount: 3,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.5,
              children: [
                ...List.generate(9, (index) {
                  return _buildNumberButton('${index + 1}');
                }),
                _buildActionButton(
                  icon: Icons.backspace,
                  onPressed: _onBackspace,
                ),
                _buildNumberButton('0'),
                _buildActionButton(
                  icon: Icons.clear,
                  onPressed: () {
                    setState(() {
                      _enteredPin = '';
                      _errorMessage = '';
                    });
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNumberButton(String number) {
    return Material(
      color: AppTheme.primaryGreen.withOpacity(0.1),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: () => _onNumberPressed(number),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(
              number,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: AppTheme.textPrimary,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return Material(
      color: AppTheme.accentOrange.withOpacity(0.2),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Icon(
              icon,
              size: 28,
              color: AppTheme.accentOrange,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildShareOptions() {
    final List<Map<String, dynamic>> shareOptions = [
      {
        'title': 'مشاركة تطبيق البائعين',
        'icon': Icons.storefront,
        'color': AppTheme.primaryGreen,
        'description': 'إرسال تطبيق البائعين للموظفين',
      },
      {
        'title': 'مشاركة تطبيق المراقبة',
        'icon': Icons.admin_panel_settings,
        'color': AppTheme.accentOrange,
        'description': 'إرسال تطبيق المراقبة للمسؤولين',
      },
      {
        'title': 'مشاركة التطبيق الرئيسي',
        'icon': Icons.settings,
        'color': AppTheme.primaryGreen,
        'description': 'إرسال التطبيق الرئيسي (محمي بكلمة سر)',
      },
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: shareOptions.length,
      itemBuilder: (context, index) {
        final option = shareOptions[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: InkWell(
            onTap: () {
              _showShareDialog(context, option['title'] as String);
            },
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: (option['color'] as Color).withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      option['icon'] as IconData,
                      size: 32,
                      color: option['color'] as Color,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          option['title'] as String,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          option['description'] as String,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.share,
                    color: AppTheme.textSecondary,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showShareDialog(BuildContext context, String appName) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'مشاركة $appName',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              _buildShareMethod(
                context,
                icon: Icons.bluetooth,
                label: 'Bluetooth',
                onTap: () => _simulateShare(context, 'Bluetooth'),
              ),
              const SizedBox(height: 12),
              _buildShareMethod(
                context,
                icon: Icons.message,
                label: 'Messenger',
                onTap: () => _simulateShare(context, 'Messenger'),
              ),
              const SizedBox(height: 12),
              _buildShareMethod(
                context,
                icon: Icons.chat,
                label: 'WhatsApp',
                onTap: () => _simulateShare(context, 'WhatsApp'),
              ),
              const SizedBox(height: 12),
              _buildShareMethod(
                context,
                icon: Icons.email,
                label: 'Email',
                onTap: () => _simulateShare(context, 'Email'),
              ),
              const SizedBox(height: 12),
              _buildShareMethod(
                context,
                icon: Icons.more_horiz,
                label: 'المزيد من الخيارات',
                onTap: () => _simulateShare(context, 'Other'),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildShareMethod(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.primaryGreen.withOpacity(0.05),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: AppTheme.primaryGreen.withOpacity(0.2),
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppTheme.primaryGreen, size: 28),
            const SizedBox(width: 16),
            Text(
              label,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(),
            const Icon(
              Icons.arrow_forward_ios,
              color: AppTheme.textSecondary,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  void _simulateShare(BuildContext context, String method) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تمت المشاركة عبر $method'),
        backgroundColor: AppTheme.successColor,
      ),
    );
  }
}
