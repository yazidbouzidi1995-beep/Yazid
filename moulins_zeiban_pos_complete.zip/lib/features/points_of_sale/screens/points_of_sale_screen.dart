import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';

class PointsOfSaleScreen extends StatefulWidget {
  const PointsOfSaleScreen({super.key});

  @override
  State<PointsOfSaleScreen> createState() => _PointsOfSaleScreenState();
}

class _PointsOfSaleScreenState extends State<PointsOfSaleScreen> {
  final List<Map<String, dynamic>> pointsOfSale = [
    {
      'id': '077020',
      'name': 'نقطة بيع 077020',
      'address': 'حي النصر، القنطرة',
      'seller': 'أحمد محمد',
      'area': 45,
      'lessor': 'محمد العبد',
      'startDate': '2024-01-01',
      'endDate': '2025-01-01',
      'duration': 12,
      'notes': 'نقطة ممتازة، حركة كبيرة',
      'isFrozen': false,
    },
    {
      'id': '077090',
      'name': 'نقطة بيع 077090',
      'address': 'حي السلام، القنطرة',
      'seller': 'خالد عمر',
      'area': 30,
      'lessor': 'علي حسن',
      'startDate': '2024-03-01',
      'endDate': '2025-03-01',
      'duration': 12,
      'notes': 'نقطة متوسطة',
      'isFrozen': true,
    },
    {
      'id': '077105',
      'name': 'نقطة بيع 077105',
      'address': 'حي الرياض، القنطرة',
      'seller': 'عبدالله سعيد',
      'area': 60,
      'lessor': 'سالم فهد',
      'startDate': '2024-06-01',
      'endDate': '2025-06-01',
      'duration': 12,
      'notes': 'نقطة كبيرة، تحتاج تطوير',
      'isFrozen': false,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('نقاط البيع'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          _showAddPointOfSaleDialog(context);
        },
        backgroundColor: AppTheme.accentOrange,
        icon: const Icon(Icons.add),
        label: const Text('إضافة نقطة بيع'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: pointsOfSale.length,
        itemBuilder: (context, index) {
          final pos = pointsOfSale[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            color: pos['isFrozen'] ? Colors.red.shade50 : null,
            child: InkWell(
              onTap: () {
                _showPointOptions(context, pos);
              },
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: pos['isFrozen']
                                ? Colors.red.withOpacity(0.1)
                                : AppTheme.primaryGreen.withOpacity(0.1),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.store,
                            color: pos['isFrozen']
                                ? Colors.red
                                : AppTheme.primaryGreen,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                pos['name'] as String,
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: pos['isFrozen'] ? Colors.red : null,
                                ),
                              ),
                              Text(
                                'البائع: ${pos['seller']}',
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ],
                          ),
                        ),
                        if (pos['isFrozen'])
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.red.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Text(
                              'مجمد',
                              style: TextStyle(
                                color: Colors.red,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const Divider(height: 20),
                    Row(
                      children: [
                        const Icon(
                          Icons.location_on,
                          size: 16,
                          color: AppTheme.textSecondary,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          pos['address'] as String,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _showPointOptions(BuildContext context, Map<String, dynamic> pos) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                pos['name'] as String,
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              _buildOptionButton(
                context,
                icon: Icons.info,
                label: 'التفاصيل',
                color: AppTheme.primaryGreen,
                onTap: () {
                  Navigator.pop(context);
                  _showPointDetails(context, pos);
                },
              ),
              const SizedBox(height: 12),
              _buildOptionButton(
                context,
                icon: pos['isFrozen'] ? Icons.play_arrow : Icons.pause,
                label: pos['isFrozen'] ? 'إلغاء التجميد' : 'تجميد',
                color: pos['isFrozen'] ? AppTheme.successColor : Colors.orange,
                onTap: () {
                  Navigator.pop(context);
                  _toggleFreeze(context, pos);
                },
              ),
              const SizedBox(height: 12),
              _buildOptionButton(
                context,
                icon: Icons.delete,
                label: 'حذف نقطة البيع',
                color: AppTheme.errorColor,
                onTap: () {
                  Navigator.pop(context);
                  _showDeleteConfirmation(context, pos);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildOptionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showPointDetails(BuildContext context, Map<String, dynamic> pos) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(pos['name'] as String),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildDetailRow('العنوان', pos['address'] as String),
                _buildDetailRow('البائع', pos['seller'] as String),
                _buildDetailRow('المساحة', '${pos['area']} م²'),
                _buildDetailRow('المؤجر', pos['lessor'] as String),
                _buildDetailRow('بداية العقد', pos['startDate'] as String),
                _buildDetailRow('نهاية العقد', pos['endDate'] as String),
                _buildDetailRow('مدة الإيجار', '${pos['duration']} شهر'),
                _buildDetailRow('معلومات إضافية', pos['notes'] as String),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إغلاق'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  void _toggleFreeze(BuildContext context, Map<String, dynamic> pos) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            pos['isFrozen'] ? 'إلغاء التجميد' : 'تجميد نقطة البيع',
          ),
          content: Text(
            pos['isFrozen']
                ? 'هل تريد إلغاء تجميد ${pos['name']}؟'
                : 'هل تريد تجميد ${pos['name']}؟',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  pos['isFrozen'] = !pos['isFrozen'];
                });
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      pos['isFrozen']
                          ? 'تم تجميد نقطة البيع'
                          : 'تم إلغاء التجميد',
                    ),
                  ),
                );
              },
              child: const Text('تأكيد'),
            ),
          ],
        );
      },
    );
  }

  void _showDeleteConfirmation(BuildContext context, Map<String, dynamic> pos) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('حذف نقطة البيع'),
          content: Text(
            'هل أنت متأكد من حذف ${pos['name']}؟
هذا الإجراء لا يمكن التراجع عنه.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  pointsOfSale.remove(pos);
                });
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم حذف نقطة البيع'),
                    backgroundColor: AppTheme.errorColor,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.errorColor,
              ),
              child: const Text('حذف'),
            ),
          ],
        );
      },
    );
  }

  void _showAddPointOfSaleDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('إضافة نقطة بيع جديدة'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'اسم نقطة البيع',
                    hintText: 'مثال: نقطة بيع 077150',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'العنوان',
                    hintText: 'حي ...، القنطرة',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'اسم البائع',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'مساحة نقطة البيع (م²)',
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'اسم المؤجر',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'بداية تاريخ عقد الإيجار',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'نهاية تاريخ عقد الإيجار',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'مدة الإيجار (شهر)',
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'معلومات إضافية',
                    hintText: 'أي ملاحظات إضافية...',
                  ),
                  maxLines: 3,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم إضافة نقطة البيع بنجاح'),
                    backgroundColor: AppTheme.successColor,
                  ),
                );
              },
              child: const Text('حفظ'),
            ),
          ],
        );
      },
    );
  }
}
