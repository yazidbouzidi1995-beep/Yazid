import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';

class TransfersScreen extends StatelessWidget {
  const TransfersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> transferOptions = [
      {
        'title': 'إضافة تحويل بين نقاط البيع',
        'icon': Icons.swap_horiz,
        'color': AppTheme.primaryGreen,
        'description': 'تحويل سلعة من نقطة بيع لأخرى',
      },
      {
        'title': 'طلبات التحويلات',
        'icon': Icons.notifications_active,
        'color': AppTheme.accentOrange,
        'badge': 2,
        'description': 'طلبات التحويل بين البائعين',
      },
      {
        'title': 'استقبال منتجات الخارجية',
        'icon': Icons.download,
        'color': AppTheme.primaryGreen,
        'description': 'إضافة بضاعة من الموردين',
      },
      {
        'title': 'إرجاع سلعة',
        'icon': Icons.undo,
        'color': AppTheme.accentOrange,
        'description': 'إرجاع بضاعة للمخزون الرئيسي',
      },
      {
        'title': 'التخلص من منتج',
        'icon': Icons.delete_forever,
        'color': AppTheme.errorColor,
        'description': 'حذف بضاعة تالفة أو منتهية',
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('التحويلات'),
        actions: [
          Container(
            margin: const EdgeInsets.all(8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppTheme.errorColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.notifications,
                  color: AppTheme.errorColor,
                  size: 20,
                ),
                const SizedBox(width: 4),
                const Text(
                  '2',
                  style: TextStyle(
                    color: AppTheme.errorColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: transferOptions.length,
        itemBuilder: (context, index) {
          final option = transferOptions[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            child: InkWell(
              onTap: () {
                _handleTransferOption(context, option['title'] as String);
              },
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: (option['color'] as Color).withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        option['icon'] as IconData,
                        size: 32,
                        color: option['color'] as Color,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            option['title'] as String,
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            option['description'] as String,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    if (option['badge'] != null)
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: const BoxDecoration(
                          color: AppTheme.errorColor,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          option['badge'].toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      )
                    else
                      const Icon(
                        Icons.arrow_forward_ios,
                        color: AppTheme.textSecondary,
                      ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _handleTransferOption(BuildContext context, String title) {
    switch (title) {
      case 'إضافة تحويل بين نقاط البيع':
        _showAddTransferDialog(context);
        break;
      case 'طلبات التحويلات':
        _showTransferRequests(context);
        break;
      case 'استقبال منتجات الخارجية':
        _showReceiveExternalProducts(context);
        break;
      case 'إرجاع سلعة':
        _showReturnProduct(context);
        break;
      case 'التخلص من منتج':
        _showDisposeProduct(context);
        break;
    }
  }

  void _showAddTransferDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('تحويل بين نقاط البيع'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'من نقطة بيع',
                  ),
                  items: [
                    'نقطة بيع 077020',
                    'نقطة بيع 077090',
                    'نقطة بيع 077105',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) {},
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'إلى نقطة بيع',
                  ),
                  items: [
                    'نقطة بيع 077020',
                    'نقطة بيع 077090',
                    'نقطة بيع 077105',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) {},
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'المنتج',
                  ),
                  items: [
                    'سميد رقيق',
                    'فرينة',
                    'زيت نباتي',
                    'سكر',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) {},
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'الكمية',
                  ),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم إرسال طلب التحويل'),
                    backgroundColor: AppTheme.successColor,
                  ),
                );
              },
              child: const Text('إرسال الطلب'),
            ),
          ],
        );
      },
    );
  }

  void _showTransferRequests(BuildContext context) {
    final List<Map<String, dynamic>> requests = [
      {
        'from': 'نقطة بيع 077020',
        'to': 'نقطة بيع 077090',
        'product': 'سميد رقيق',
        'quantity': 20,
        'status': 'pending',
      },
      {
        'from': 'نقطة بيع 077105',
        'to': 'نقطة بيع 077020',
        'product': 'فرينة',
        'quantity': 15,
        'status': 'pending',
      },
    ];

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('طلبات التحويلات'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: requests.length,
              itemBuilder: (context, index) {
                final request = requests[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${request['from']} → ${request['to']}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text('${request['product']}: ${request['quantity']} وحدة'),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('تمت الموافقة على التحويل'),
                                      backgroundColor: AppTheme.successColor,
                                    ),
                                  );
                                },
                                child: const Text('موافقة'),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: const Text('رفض'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إغلاق'),
            ),
          ],
        );
      },
    );
  }

  void _showReceiveExternalProducts(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('استقبال منتجات خارجية'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'المنتج',
                  ),
                  items: [
                    'زيت نباتي',
                    'سكر',
                    'أرز',
                    'معجون طماطم',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) {},
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'الكمية المستلمة',
                  ),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم إضافة الكمية للمخزون الخارجي'),
                    backgroundColor: AppTheme.successColor,
                  ),
                );
              },
              child: const Text('تأكيد'),
            ),
          ],
        );
      },
    );
  }

  void _showReturnProduct(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('إرجاع سلعة'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'نقطة البيع',
                  ),
                  items: [
                    'نقطة بيع 077020',
                    'نقطة بيع 077090',
                    'نقطة بيع 077105',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) {},
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'المنتج',
                  ),
                  items: [
                    'سميد رقيق',
                    'فرينة',
                    'زيت نباتي',
                    'سكر',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) {},
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'الكمية المرجعة',
                  ),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم إرجاع الكمية للمخزون الرئيسي'),
                    backgroundColor: AppTheme.successColor,
                  ),
                );
              },
              child: const Text('تأكيد الإرجاع'),
            ),
          ],
        );
      },
    );
  }

  void _showDisposeProduct(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('التخلص من منتج'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'نقطة البيع',
                  ),
                  items: [
                    'نقطة بيع 077020',
                    'نقطة بيع 077090',
                    'نقطة بيع 077105',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) {},
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'المنتج',
                  ),
                  items: [
                    'سميد رقيق',
                    'فرينة',
                    'زيت نباتي',
                    'سكر',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) {},
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'الكمية',
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'سبب التخلص',
                    hintText: 'تلف، انتهاء صلاحية...',
                  ),
                  maxLines: 2,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم التخلص من الكمية نهائيًا'),
                    backgroundColor: AppTheme.errorColor,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.errorColor,
              ),
              child: const Text('تأكيد التخلص'),
            ),
          ],
        );
      },
    );
  }
}
