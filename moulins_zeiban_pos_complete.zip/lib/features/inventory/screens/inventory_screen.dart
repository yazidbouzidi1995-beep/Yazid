import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';

class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> inventoryTypes = [
      {
        'title': 'مخزون المطحنة',
        'subtitle': 'منتجات الشركة - لا نهائي',
        'icon': Icons.factory,
        'color': AppTheme.primaryGreen,
        'count': '∞',
      },
      {
        'title': 'مخزون السلع الخارجية',
        'subtitle': 'منتجات الموردين',
        'icon': Icons.local_shipping,
        'color': AppTheme.accentOrange,
        'count': '24',
      },
      {
        'title': 'مخزون نقاط البيع',
        'subtitle': 'بضاعة كل نقطة',
        'icon': Icons.store,
        'color': AppTheme.primaryGreen,
        'count': '8',
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('المخزونات'),
      ),
      body: Container(
        padding: const EdgeInsets.all(16),
        child: ListView.builder(
          itemCount: inventoryTypes.length,
          itemBuilder: (context, index) {
            final item = inventoryTypes[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: InkWell(
                onTap: () {
                  _showInventoryDetail(context, item['title'] as String);
                },
                borderRadius: BorderRadius.circular(16),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: (item['color'] as Color).withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          item['icon'] as IconData,
                          size: 32,
                          color: item['color'] as Color,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['title'] as String,
                              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              item['subtitle'] as String,
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: AppTheme.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: (item['color'] as Color).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          item['count'] as String,
                          style: TextStyle(
                            color: item['color'] as Color,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _showInventoryDetail(BuildContext context, String title) {
    // Mock data for each inventory type
    List<Map<String, dynamic>> items = [];

    if (title == 'مخزون المطحنة') {
      items = [
        {'name': 'سميد رقيق', 'quantity': '∞'},
        {'name': 'سميد خشن', 'quantity': '∞'},
        {'name': 'فرينة', 'quantity': '∞'},
        {'name': 'نخالة', 'quantity': '∞'},
      ];
    } else if (title == 'مخزون السلع الخارجية') {
      items = [
        {'name': 'زيت نباتي', 'quantity': '150'},
        {'name': 'سكر', 'quantity': '200'},
        {'name': 'أرز', 'quantity': '80'},
        {'name': 'معجون طماطم', 'quantity': '120'},
      ];
    } else {
      items = [
        {'name': 'نقطة بيع 077020', 'quantity': '45 منتج'},
        {'name': 'نقطة بيع 077090', 'quantity': '32 منتج'},
        {'name': 'نقطة بيع 077105', 'quantity': '28 منتج'},
      ];
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => InventoryDetailScreen(
          title: title,
          items: items,
        ),
      ),
    );
  }
}

class InventoryDetailScreen extends StatelessWidget {
  final String title;
  final List<Map<String, dynamic>> items;

  const InventoryDetailScreen({
    super.key,
    required this.title,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.primaryGreen.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.inventory,
                  color: AppTheme.primaryGreen,
                ),
              ),
              title: Text(
                item['name'] as String,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              trailing: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: AppTheme.accentOrange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  item['quantity'] as String,
                  style: const TextStyle(
                    color: AppTheme.accentOrange,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
