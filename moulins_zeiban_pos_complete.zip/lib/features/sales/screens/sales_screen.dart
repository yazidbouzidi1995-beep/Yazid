import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/app_theme.dart';

class SalesScreen extends StatefulWidget {
  const SalesScreen({super.key});

  @override
  State<SalesScreen> createState() => _SalesScreenState();
}

class _SalesScreenState extends State<SalesScreen> {
  String? selectedPOS;
  DateTime? startDate;
  DateTime? endDate;
  String selectedPeriod = 'today';

  final List<Map<String, dynamic>> pointsOfSale = [
    {'id': '077020', 'name': 'نقطة بيع 077020'},
    {'id': '077090', 'name': 'نقطة بيع 077090'},
    {'id': '077105', 'name': 'نقطة بيع 077105'},
  ];

  final Map<String, List<Map<String, dynamic>>> salesData = {
    '077020': [
      {'date': '2026-05-06', 'amount': 12500, 'items': 45},
      {'date': '2026-05-05', 'amount': 9800, 'items': 38},
      {'date': '2026-05-04', 'amount': 11200, 'items': 42},
    ],
    '077090': [
      {'date': '2026-05-06', 'amount': 8500, 'items': 32},
      {'date': '2026-05-05', 'amount': 7200, 'items': 28},
    ],
    '077105': [
      {'date': '2026-05-06', 'amount': 15000, 'items': 55},
      {'date': '2026-05-05', 'amount': 13200, 'items': 48},
    ],
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المبيعات'),
      ),
      body: Column(
        children: [
          // Filters Section
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                // Point of Sale Selection
                DropdownButtonFormField<String>(
                  value: selectedPOS,
                  decoration: const InputDecoration(
                    labelText: 'اختر نقطة البيع',
                    prefixIcon: Icon(Icons.store),
                  ),
                  hint: const Text('اختر نقطة البيع'),
                  items: pointsOfSale.map((pos) {
                    return DropdownMenuItem<String>(
                      value: pos['id'] as String,
                      child: Text(pos['name'] as String),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedPOS = value;
                    });
                  },
                ),
                const SizedBox(height: 16),
                // Period Selection
                Row(
                  children: [
                    Expanded(
                      child: _buildPeriodButton('اليوم', 'today'),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildPeriodButton('الشهر', 'month'),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildPeriodButton('فترة', 'custom'),
                    ),
                  ],
                ),
                if (selectedPeriod == 'custom') ...[
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: InkWell(
                          onTap: () => _selectDate(context, true),
                          child: InputDecorator(
                            decoration: const InputDecoration(
                              labelText: 'من تاريخ',
                              prefixIcon: Icon(Icons.calendar_today),
                            ),
                            child: Text(
                              startDate != null
                                  ? DateFormat('yyyy-MM-dd').format(startDate!)
                                  : 'اختر التاريخ',
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: InkWell(
                          onTap: () => _selectDate(context, false),
                          child: InputDecorator(
                            decoration: const InputDecoration(
                              labelText: 'إلى تاريخ',
                              prefixIcon: Icon(Icons.calendar_today),
                            ),
                            child: Text(
                              endDate != null
                                  ? DateFormat('yyyy-MM-dd').format(endDate!)
                                  : 'اختر التاريخ',
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          // Results Section
          Expanded(
            child: selectedPOS == null
                ? _buildEmptyState()
                : _buildSalesResults(),
          ),
        ],
      ),
    );
  }

  Widget _buildPeriodButton(String label, String period) {
    final isSelected = selectedPeriod == period;
    return ElevatedButton(
      onPressed: () {
        setState(() {
          selectedPeriod = period;
        });
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: isSelected ? AppTheme.primaryGreen : Colors.grey.shade200,
        foregroundColor: isSelected ? Colors.white : AppTheme.textPrimary,
        padding: const EdgeInsets.symmetric(vertical: 12),
      ),
      child: Text(label),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.analytics_outlined,
            size: 80,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 16),
          Text(
            'اختر نقطة بيع لعرض المبيعات',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSalesResults() {
    final sales = salesData[selectedPOS] ?? [];
    final totalAmount = sales.fold<int>(0, (sum, sale) => sum + (sale['amount'] as int));
    final totalItems = sales.fold<int>(0, (sum, sale) => sum + (sale['items'] as int));

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Summary Cards
          Row(
            children: [
              Expanded(
                child: _buildSummaryCard(
                  'إجمالي المبيعات',
                  '$totalAmount دج',
                  Icons.attach_money,
                  AppTheme.primaryGreen,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildSummaryCard(
                  'عدد العمليات',
                  '$totalItems',
                  Icons.shopping_bag,
                  AppTheme.accentOrange,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          // Sales List
          ...sales.map((sale) {
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryGreen.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.receipt,
                    color: AppTheme.primaryGreen,
                  ),
                ),
                title: Text(
                  'تاريخ: ${sale['date']}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text('${sale['items']} عملية بيع'),
                trailing: Text(
                  '${sale['amount']} دج',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: AppTheme.accentOrange,
                    fontSize: 16,
                  ),
                ),
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildSummaryCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 32),
          const SizedBox(height: 12),
          Text(
            title,
            style: TextStyle(
              color: color,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Future<void> _selectDate(BuildContext context, bool isStart) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2024),
      lastDate: DateTime(2027),
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          startDate = picked;
        } else {
          endDate = picked;
        }
      });
    }
  }
}
