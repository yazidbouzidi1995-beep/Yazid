import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final List<Map<String, dynamic>> products = [
    {
      'name': 'سميد رقيق',
      'code': 'SM001',
      'inventoryType': 'مخزون المطحنة',
      'brand': 'مطاحن الزيبان',
      'unit': 'كيس',
      'price': 450.0,
      'supplier': 'مطاحن الزيبان',
      'capacityType': 'كلغ',
      'capacityValue': 50,
    },
    {
      'name': 'زيت نباتي',
      'code': 'ZN001',
      'inventoryType': 'مخزون السلع الخارجية',
      'brand': 'الشرق',
      'unit': 'علبة',
      'price': 120.0,
      'supplier': 'شركة الزيوت',
      'capacityType': 'لتر',
      'capacityValue': 5,
    },
    {
      'name': 'سكر',
      'code': 'SK001',
      'inventoryType': 'مخزون السلع الخارجية',
      'brand': 'السكر الوطني',
      'unit': 'كيس',
      'price': 85.0,
      'supplier': 'شركة السكر',
      'capacityType': 'كلغ',
      'capacityValue': 50,
    },
    {
      'name': 'فرينة',
      'code': 'FR001',
      'inventoryType': 'مخزون المطحنة',
      'brand': 'مطاحن الزيبان',
      'unit': 'كيس',
      'price': 380.0,
      'supplier': 'مطاحن الزيبان',
      'capacityType': 'فراك',
      'capacityValue': null,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المنتجات'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          _showAddProductDialog(context);
        },
        backgroundColor: AppTheme.accentOrange,
        icon: const Icon(Icons.add),
        label: const Text('إضافة منتج'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            child: InkWell(
              onTap: () {
                _showProductDetail(context, product);
              },
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryGreen.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.inventory_2,
                        color: AppTheme.primaryGreen,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            product['name'] as String,
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'الرمز: ${product['code']}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            product['inventoryType'] as String,
                            style: TextStyle(
                              color: product['inventoryType'] == 'مخزون المطحنة'
                                  ? AppTheme.primaryGreen
                                  : AppTheme.accentOrange,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '${product['price']} دج',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: AppTheme.accentOrange,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${product['capacityValue'] ?? ''} ${product['capacityType']}',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _showProductDetail(BuildContext context, Map<String, dynamic> product) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(product['name'] as String),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildDetailRow('رمز المنتج', product['code'] as String),
                _buildDetailRow('نوع المخزون', product['inventoryType'] as String),
                _buildDetailRow('العلامة', product['brand'] as String),
                _buildDetailRow('الوحدة', product['unit'] as String),
                _buildDetailRow('السعر', '${product['price']} دج'),
                _buildDetailRow('المورد', product['supplier'] as String),
                _buildDetailRow(
                  'السعة',
                  '${product['capacityValue'] ?? ''} ${product['capacityType']}',
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إغلاق'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  void _showAddProductDialog(BuildContext context) {
    String selectedCapacityType = 'كلغ';
    String selectedInventoryType = 'مخزون المطحنة';

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('إضافة منتج جديد'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'اسم المنتج',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'رمز المنتج',
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: selectedInventoryType,
                      decoration: const InputDecoration(
                        labelText: 'نوع المخزون',
                      ),
                      items: [
                        'مخزون المطحنة',
                        'مخزون السلع الخارجية',
                      ].map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          selectedInventoryType = newValue!;
                        });
                      },
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'اسم العلامة',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'الوحدة',
                        hintText: 'كيس، علبة، كرتونة...',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'السعر بالدينار الجزائري (دج)',
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'اسم المورد',
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: selectedCapacityType,
                      decoration: const InputDecoration(
                        labelText: 'سعة المنتج',
                      ),
                      items: [
                        'كلغ',
                        'غرام',
                        'لتر',
                        'فراك',
                      ].map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          selectedCapacityType = newValue!;
                        });
                      },
                    ),
                    if (selectedCapacityType != 'فراك') ...[
                      const SizedBox(height: 12),
                      TextField(
                        decoration: const InputDecoration(
                          labelText: 'رقم السعة',
                        ),
                        keyboardType: TextInputType.number,
                      ),
                    ],
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('إلغاء'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('تم إضافة المنتج بنجاح'),
                        backgroundColor: AppTheme.successColor,
                      ),
                    );
                  },
                  child: const Text('حفظ'),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
